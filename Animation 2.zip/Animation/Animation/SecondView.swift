//
//  SecondView.swift
//  Animation
//
//  Created by hb on 11/09/23.
//

import UIKit

class SecondView: UIView {
    
    @IBOutlet weak var lblReady: UILabel!
    
    @IBOutlet weak var lblSecond: UILabel!
    
    @IBOutlet weak var middleView: UIView!
    @IBOutlet weak var bottomView: UIView!
    
    override open func awakeFromNib() {
        super.awakeFromNib()
        self.bottomView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        self.lblReady.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        self.lblSecond.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        self.middleView.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 2.0) {
            self.lblReady.transform = .identity
            self.lblSecond.transform = .identity
            self.middleView.transform = .identity
            self.bottomView.transform = .identity
        }
    }
 
}
