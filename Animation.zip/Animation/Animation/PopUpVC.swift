//
//  PopUpVC.swift
//  Animation
//
//  Created by hb on 09/09/23.
//

import UIKit

class PopUpVC: UIViewController {
    
    //MARK: IBoutlates
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var topMainView: UIView!
    @IBOutlet weak var bottomMainview: UIView!
    
    //MARK: Variables Declaration
    
    var btnTitle = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    }
    
    //MARK: ViewLive Cycles
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.view.frame = CGRect(x: 0, y: UIScreen.main.bounds.height / 3, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 2)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        mainView.transform = CGAffineTransform(translationX: self.view.frame.width, y: 0)
        UIView.animate(withDuration: 0.8, delay: 0, options: .curveEaseIn) {
            self.mainView.transform = .identity
            
        }
        
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    //MARK: IBAction
    
    @IBAction func btnNextTap(_ sender: UIButton) {
        if btnTitle == 1 {
            btnTitle = 2
            mainView.isHidden = true
            guard let myView = Bundle.main.loadNibNamed("AnimationView", owner: self, options: nil)?[0] as? AnimationView else { return  }
            self.topMainView.addSubview(myView)
            topMainView.transform = CGAffineTransform(translationX: self.view.frame.width, y: 0)
            UIView.animate(withDuration: 0.8, delay: 0, options: .curveEaseIn) {
                self.topMainView.transform = .identity
            }
            
        }
        else if btnTitle == 2 {
            btnTitle = 3
            btnNext.backgroundColor = .black
            btnNext.setTitle("Confirm", for: .normal)
            topMainView.isHidden = true
            guard let myView = Bundle.main.loadNibNamed("SecondView", owner: self, options: nil)?[0] as? SecondView else { return  }
            self.bottomMainview.addSubview(myView)
            bottomMainview.transform = CGAffineTransform(translationX: self.view.frame.width, y: 0)
            UIView.animate(withDuration: 0.8, delay: 0, options: .curveEaseIn) {
                self.bottomMainview.transform = .identity
            }
        } else if btnTitle == 3 {
            guard let vC = self.storyboard?.instantiateViewController(withIdentifier: "ThankYouVc") as? ThankYouVc else { return
            }
            self.navigationController?.pushViewController(vC, animated: true)
        }
    }
}
